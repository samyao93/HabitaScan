// Suppression du compte par l'utilisateur lui-même (Loi 25 : droit de faire supprimer ses renseignements).
// Supprime les photos de pièce d'identité, les lignes de l'utilisateur, puis le compte.
// Utilise la clé service_role, fournie automatiquement aux fonctions par Supabase (jamais dans l'app).
import { createClient } from "npm:@supabase/supabase-js@2";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const json = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });
  if (req.method !== "POST") return json({ error: "methode" }, 405);

  const url = Deno.env.get("SUPABASE_URL")!;
  const jeton = (req.headers.get("Authorization") || "").replace(/^Bearer /, "");
  const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });

  // Qui fait la demande : seulement l'utilisateur connecté, pour son propre compte.
  const { data: u, error: eu } = await admin.auth.getUser(jeton);
  if (eu || !u?.user) return json({ error: "non_connecte" }, 401);
  const uid = u.user.id;

  // 1. Photos de pièce d'identité
  const { data: fichiers } = await admin.storage.from("pieces-identite").list(uid, { limit: 100 });
  if (fichiers && fichiers.length) {
    await admin.storage.from("pieces-identite").remove(fichiers.map((f) => `${uid}/${f.name}`));
  }
  // 2. Lignes de l'utilisateur (au cas où une table n'a pas de suppression en cascade)
  for (const [table, col] of [["signalements", "user_id"], ["verifications", "user_id"], ["admins", "user_id"], ["profiles", "id"]]) {
    await admin.from(table).delete().eq(col, uid);
  }
  // 3. Le compte
  const { error } = await admin.auth.admin.deleteUser(uid);
  if (error) return json({ error: "suppression" }, 500);
  return json({ ok: true });
});
