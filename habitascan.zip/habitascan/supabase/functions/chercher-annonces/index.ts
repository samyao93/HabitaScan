// Recherche d'annonces de logement récentes sur le web, pour l'écran « Trouver un logement ».
// Utilise Brave Search API (5 $ US par 1 000 requêtes, 5 $ de crédit gratuit par mois). La clé reste sur le serveur.
// Déploiement : voir LISEZ-MOI (secret BRAVE_API_KEY).
// L'app reçoit seulement le titre, le lien et l'extrait publics de chaque résultat ; elle fait le tri elle-même.
// Les pages des sites ne sont jamais téléchargées : seuls les résultats du moteur de recherche sont utilisés.

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const SITES = ["kijiji.ca", "centris.ca", "realtor.ca", "duproprio.com", "rentals.ca", "louer.ca", "kangalou.com",
  "logisquebec.com", "padmapper.com", "lespac.com", "zumper.com", "craigslist.org"];
const VILLE = /^[\p{L} .'-]{2,40}$/u;

type Resultat = { titre: string; url: string; extrait: string; age: string };

async function brave(q: string, cle: string): Promise<Resultat[]> {
  const u = new URL("https://api.search.brave.com/res/v1/web/search");
  u.searchParams.set("q", q);
  u.searchParams.set("country", "CA");
  u.searchParams.set("search_lang", "fr");
  u.searchParams.set("count", "20");
  u.searchParams.set("freshness", "pm"); // dernier mois
  const r = await fetch(u, { headers: { "Accept": "application/json", "X-Subscription-Token": cle } });
  if (!r.ok) throw new Error("brave " + r.status);
  const d = await r.json();
  return ((d.web && d.web.results) || []).map((x: Record<string, unknown>) => ({
    titre: String(x.title || "").replace(/<[^>]+>/g, "").slice(0, 200),
    url: String(x.url || ""),
    extrait: [x.description, ...((x.extra_snippets as string[]) || [])].filter(Boolean).join(" ").replace(/<[^>]+>/g, "").slice(0, 600),
    age: String(x.age || "").slice(0, 40),
  }));
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const json = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });
  if (req.method !== "POST") return json({ error: "methode" }, 405);

  const cle = Deno.env.get("BRAVE_API_KEY");
  if (!cle) return json({ error: "non_configure" }, 503);

  let ville = "", ch = "";
  try {
    const b = await req.json();
    ville = String(b.ville || "");
    ch = String(b.ch || "");
  } catch {
    return json({ error: "requete" }, 400);
  }
  if (!VILLE.test(ville) || !["", "1", "2", "3"].includes(ch)) return json({ error: "parametres" }, 400);

  // Format québécois : 1 ch. ≈ 3 1/2, 2 ch. ≈ 4 1/2, 3 ch. ≈ 5 1/2
  const taille = ch ? `${Number(ch) + 2} 1/2` : "";
  const requetes = [
    `logement à louer ${taille} ${ville}`.replace(/\s+/g, " "),
    `appartement à louer ${ch ? ch + " chambres " : ""}${ville} kijiji`,
  ];
  try {
    const lots = await Promise.all(requetes.map((q) => brave(q, cle)));
    const vus = new Set<string>();
    const resultats = lots.flat().filter((r) => {
      let h = "";
      try { h = new URL(r.url).hostname.replace(/^(www|m|fr|en)\./, ""); } catch { return false; }
      if (!SITES.some((s) => h === s || h.endsWith("." + s))) return false;
      const k = r.url.split(/[?#]/)[0];
      if (vus.has(k)) return false;
      vus.add(k);
      return true;
    });
    return json({ resultats });
  } catch (_e) {
    return json({ error: "recherche" }, 502);
  }
});
