// Recherche d'image inversée : les photos de l'annonce sont-elles publiées ailleurs sur le web ?
// Utilise Google Cloud Vision (détection web). La clé reste sur le serveur, jamais dans l'app.
// Déploiement : voir LISEZ-MOI (secret GOOGLE_VISION_KEY).
// L'image n'est ni enregistrée ni journalisée : elle est envoyée à Google Vision puis oubliée.

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const MAX_BASE64 = 6_000_000; // environ 4,5 Mo d'image

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const json = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });
  if (req.method !== "POST") return json({ error: "methode" }, 405);

  const cle = Deno.env.get("GOOGLE_VISION_KEY");
  if (!cle) return json({ error: "non_configure" }, 503);

  let image = "";
  try {
    ({ image } = await req.json());
  } catch {
    return json({ error: "requete" }, 400);
  }
  if (typeof image !== "string" || !image || image.length > MAX_BASE64 || !/^[A-Za-z0-9+/=]+$/.test(image)) {
    return json({ error: "image" }, 400);
  }

  const r = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${encodeURIComponent(cle)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      requests: [{ image: { content: image }, features: [{ type: "WEB_DETECTION", maxResults: 10 }] }],
    }),
  });
  if (!r.ok) return json({ error: "vision", status: r.status }, 502);
  const data = await r.json();
  const web = data?.responses?.[0]?.webDetection ?? {};
  // Pages où une image identique ou partiellement identique a été trouvée.
  const pages: string[] = (web.pagesWithMatchingImages ?? [])
    .map((p: { url?: string }) => p.url)
    .filter((u: unknown): u is string => typeof u === "string" && /^https?:\/\//.test(u));
  return json({ pages: [...new Set(pages)].slice(0, 10) });
});
