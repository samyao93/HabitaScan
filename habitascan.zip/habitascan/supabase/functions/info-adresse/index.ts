// Adresse → numéro de lot, avec les services publics du gouvernement du Québec (données ouvertes) :
// 1. géocodeur Adresses Québec (MRNF, licence CC-BY 4.0) ;
// 2. couche « Lots du cadastre rénové » (champ NO_LOT).
// Aucun nom de propriétaire n'est recherché : les rôles en données ouvertes caviardent les noms,
// et il est interdit de les réidentifier.
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const GEO = "https://servicescarto.mern.gouv.qc.ca/pes/rest/services/Territoire/AdressesQuebec_Geocodage/GeocodeServer/findAddressCandidates";
const CAD = "https://geo.environnement.gouv.qc.ca/donnees/rest/services/Reference/Cadastre_allege/MapServer/0/query";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const json = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), { status, headers: { ...CORS, "Content-Type": "application/json" } });
  let adresse = "";
  try { adresse = String((await req.json()).adresse || "").trim(); } catch { return json({ error: "requete" }, 400); }
  if (adresse.length < 6 || adresse.length > 200) return json({ error: "adresse" }, 400);
  try {
    const g = await (await fetch(`${GEO}?SingleLine=${encodeURIComponent(adresse)}&outSR=4326&maxLocations=1&f=json`, { signal: AbortSignal.timeout(8000) })).json();
    const c = g?.candidates?.[0];
    if (!c?.location || (c.score != null && c.score < 80)) return json({ trouve: false });
    const q = await (await fetch(`${CAD}?geometry=${c.location.x},${c.location.y}&geometryType=esriGeometryPoint&inSR=4326&spatialRel=esriSpatialRelIntersects&outFields=NO_LOT&returnGeometry=false&f=json`, { signal: AbortSignal.timeout(8000) })).json();
    const lots = [...new Set((q?.features || []).map((f: { attributes?: { NO_LOT?: string } }) => String(f.attributes?.NO_LOT || "").replace(/\D/g, "")).filter(Boolean))];
    return json({ trouve: true, adresse: c.address || adresse, lots });
  } catch {
    return json({ error: "service" }, 502);
  }
});
