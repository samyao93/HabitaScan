{
/* ===== Configuration Supabase (clé publiable : peut être visible dans le navigateur) ===== */
const SUPABASE_URL = "https://oyiiaqyepihkawzkkjpi.supabase.co";
const SUPABASE_KEY = "sb_publishable_LhDVlSvpyM-bkW-QSp0lsw_wgNIsELX";
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

const ROLE={"Montréal":"https://montreal.ca/consulter-les-roles-devaluation-fonciere","Québec":"https://www.ville.quebec.qc.ca/citoyens/taxes_evaluation/evaluation_fonciere/role/"};
const REGISTRE="https://www.quebec.ca/habitation-territoire/achat-vente/recherche-propriete/historique";
/* Seuils à valider avec les tests sur de vraies annonces. */
const BAS=0.75,HAUT=1.4;
const MOTS_ARGENT=["dépôt","depot","deposit","acompte","réserver","reserver","frais de dossier","2 mois d'avance","deux mois d'avance","western union","carte-cadeau","carte cadeau","gift card","bitcoin","crypto"];
const MOTS_SCENARIO=["à l'étranger","a l'etranger","hors du pays","out of the country","pas de visite","pas possible de visiter","je suis en voyage","missionnaire","clés par la poste","cles par la poste","envoyer les clés","courrier les clés","airbnb"];

/* Sites d'annonces connus au Québec. */
const SITES=[{d:"facebook.com"},{d:"fb.com"},{d:"kijiji.ca"},{d:"lespac.com"},{d:"logisquebec.com"},{d:"rentals.ca"},{d:"padmapper.com"},{d:"centris.ca"},{d:"duproprio.com"},{d:"zumper.com"},{d:"craigslist.org"},{d:"liv.rent"},{d:"kangalou.com"},{d:"louer.ca"}];
/* Lien comparable entre utilisateurs : sans paramètres de suivi, sans fin variable. */
function normaliser(t){const m=String(t||"").match(/https?:\/\/[^\s]+/i);if(!m)return null;
 try{const u=new URL(m[0]);if(!/^https?:$/.test(u.protocol))return null;const h=u.hostname.toLowerCase().replace(/^(www|m|web)\./,"");
  const p=u.pathname.replace(/\/+$/,"");const mk=p.match(/\/marketplace\/item\/(\d+)/);
  return mk?`https://facebook.com/marketplace/item/${mk[1]}`:`https://${h}${p}`.slice(0,500)}catch(e){return null}}
let LOYERS={},PROFIL=null,HIST=[],F={},REGISTRE_PRET=false,ANONYME=true,SESSION=false;
const LS={get:k=>{try{return JSON.parse(localStorage.getItem(k))}catch(e){return null}},set:(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
/* ===== Lecture automatique d'une annonce (texte collé, partagé ou lu sur une capture) ===== */
/* Notation québécoise : un 4 ½ = 2 chambres (pièces moins 2 : cuisine et salon). Un 1 ½ ou 2 ½ = studio. */
function extraireAnnonce(brut,villes){
 const t=String(brut||"").replace(/\u00a0|\u202f/g," "),bas=t.toLowerCase(),r={};
 const url=t.match(/https?:\/\/[^\s]+/i);if(url)r.lien=url[0];
 /* Prix : un montant de 300 à 9 999 $ collé à un symbole $ ou à « par mois » / « /mois » / « month ». */
 const prix=[...t.matchAll(/(?:\$\s?(\d{1,2}[ ,.]?\d{3}|\d{3,4})(?![\d])|(\d{1,2}[ ,.]?\d{3}|\d{3,4})\s?(?:\$|dollars?\b|par mois|\/\s?mois|\/\s?mo\b|\/\s?month|per month))/gi)]
  .map(m=>parseInt((m[1]||m[2]).replace(/[ ,.]/g,""),10)).filter(n=>n>=300&&n<=9999);
 if(!prix.length){const l=t.match(/(?:loyer|prix|rent)\s*:?\s*(\d{1,2}[ ,.]?\d{3}|\d{3,4})(?!\d)/i);if(l){const n=parseInt(l[1].replace(/[ ,.]/g,""),10);if(n>=300&&n<=9999)prix.push(n)}}
 if(prix.length)r.prix=String(prix[0]);
 /* Chambres : « 4 1/2 », « 4½ », « 4.5 », « 2 chambres », « 2 cc », « 2 bedrooms », « 2 br ». */
 const demi=bas.match(/\b([1-9])\s?(?:½|1\/2|\.5|,5)(?!\d)/);
 const ch=bas.match(/\b([1-6])\s?(?:chambres?|cc\b|c\.c\.|bedrooms?|beds?\b|br\b|bdr)/);
 if(ch)r.ch=String(Math.min(+ch[1],3));
 else if(demi&&+demi[1]>=3)r.ch=String(Math.min(+demi[1]-2,3));
 /* Ville : une des villes de référence nommée dans le texte. */
 const norm=s=>s.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase();
 const nb=norm(t);const v=(villes||[]).find(x=>new RegExp("\\b"+norm(x).replace(/[-\s]/g,"[-\\s]")+"\\b").test(nb));
 if(v)r.ville=v;
 if(/\bcession\b|\btransfert de bail\b|\blease transfer\b/.test(bas))r.cession="oui";
 return r;
}
function resumeLecture(r){const p=[];if(r.prix)p.push(Number(r.prix).toLocaleString("fr-CA")+" $");if(r.ch)p.push(r.ch==="3"?"3 ch. et plus":r.ch+" ch.");if(r.ville)p.push(r.ville);if(r.cession)p.push("cession de bail");return p.join(" · ")}

/* Lecture du texte d'une capture d'écran, directement sur le téléphone (Tesseract.js, chargé seulement au besoin). */
let tesseractPret=null;
function chargerTesseract(){if(window.Tesseract)return Promise.resolve();if(tesseractPret)return tesseractPret;
 tesseractPret=new Promise((ok,ko)=>{const s=document.createElement("script");s.src="https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js";s.onload=ok;s.onerror=()=>{tesseractPret=null;ko(new Error("tesseract"))};document.head.appendChild(s)});
 return tesseractPret}
async function lireCapture(image){await chargerTesseract();const {data}=await Tesseract.recognize(image,"fra+eng");return data&&data.text||""}

/* ===== Signalements ===== */
const MOTIFS={argent_avant_bail:"On m'a demandé de l'argent avant le bail",faux_proprietaire:"La personne n'est pas le vrai propriétaire",logement_inexistant:"Le logement n'existe pas ou n'est pas à louer",photos_volees:"Les photos viennent d'une autre annonce",autre:"Autre raison"};
/* Seuils de départ, à ajuster après les premiers tests. */
const SEUIL_JAUNE=1,SEUIL_ROUGE=3;
function itemSignalements(n){if(!n)return null;
 return n>=SEUIL_ROUGE?{c:"r",t:`<b>Annonce signalée ${n} fois</b> par des utilisateurs à l'identité confirmée.`}
  :{c:"y",t:`<b>Annonce signalée ${n} fois</b> par ${n>1?"des utilisateurs":"un utilisateur"} à l'identité confirmée. Redouble de prudence.`}}
const vueSignaler=(F,retour)=>`${top(retour,"Signaler")}
<h2>Signaler cette annonce</h2><p class="soft">Ton signalement prévient les prochaines personnes qui vérifient la même annonce. Ton nom n'est jamais montré.</p>
<form class="card" id="f-sig" novalidate>
<div class="q">Qu'est-ce qui s'est passé ?<div class="choix" role="radiogroup" aria-label="Raison">${Object.entries(MOTIFS).map(([k,l])=>`<button type="button" data-motif="${k}" aria-pressed="${F.motif===k}">${l}</button>`).join("")}</div></div>
<label style="flex-direction:row;align-items:flex-start;gap:10px;font-weight:500"><input type="checkbox" id="bonnefoi" style="width:22px;min-height:22px;margin-top:2px">Je signale de bonne foi, à partir de ce que j'ai vécu.</label>
<p class="err" id="e" hidden></p>
<button class="btn" id="go">Envoyer le signalement</button></form>
<p class="hint">Un faux signalement peut causer du tort à une personne honnête. Seuls les comptes à l'identité confirmée peuvent signaler.</p>`;
function lierSignaler(F){app.querySelectorAll("[data-motif]").forEach(b=>b.onclick=()=>{F.motif=b.dataset.motif;app.querySelectorAll("[data-motif]").forEach(x=>x.setAttribute("aria-pressed",x===b))})}
function validerSignal(F){if(!F.motif)return "Choisis une raison.";if(!$("#bonnefoi").checked)return "Coche la case pour confirmer.";return ""}
const vueSignalOk=()=>`${top(null,"Merci")}
<svg class="seal" role="img" aria-label="Signalement reçu"><use href="#seal"/></svg>
<h1>Signalement reçu</h1><p class="soft">Les prochaines personnes qui vérifient cette annonce verront l'avertissement.</p>
<button class="btn" data-go="accueil">Retour à l'accueil</button>`;
const boutonSignaler=F=>F.lienN?`<button class="btn ghost" id="signaler">Signaler cette annonce comme frauduleuse</button>`:`<p class="hint">Pour pouvoir signaler cette annonce, ajoute son lien.</p>`;

/* ===== Module Vérif-Réno : règles communes (démo et version Supabase) =====
   Sources : RBQ, liste des sous-catégories de licence ; OPC, guide du commerce itinérant
   (LPC art. 55, 59, 60, 60.1, 321 ; Règlement d'application, art. 7). */
const LIENS={
 rbq:"https://www.rbq.gouv.qc.ca/vous-etes/citoyen/verifier-la-licence-dun-entrepreneur",
 souscat:"https://www.rbq.gouv.qc.ca/fileadmin/medias/pdf/Publications/francais/AnnexeListeSousCategories.pdf",
 general:"https://www.rbq.gouv.qc.ca/licence/determiner-vos-sous-categories-de-licence/entrepreneur-general/",
 opc:"https://www.opc.gouv.qc.ca/se-renseigner/",
 itinerant:"https://cdn.opc.gouv.qc.ca/media/documents/a-propos/AccesInformation/2025/344002584_Document8.pdf",
 lpc601:"https://cdn.opc.gouv.qc.ca/media/documents/a-propos/AccesInformation/2025/344002584_Document6.pdf",
 art46:"https://www.rbq.gouv.qc.ca/fileadmin/medias/pdf/Decisions/decision_5800-8673_9369-5013-Quebec-inc.pdf"};
const lien=(href,txt)=>`<a href="${href}" target="_blank" rel="noopener">${txt}</a>`;
/* art7 : contrat signé à domicile = commerce itinérant, même si le client a invité l'entrepreneur (Règlement, art. 7). */
const TRAVAUX={
 toiture:{l:"Toiture, isolation, revêtement extérieur",sc:["7"],nomSc:"7",art7:true},
 portes:{l:"Portes et fenêtres",sc:["8"],nomSc:"8",art7:true},
 plomberie:{l:"Plomberie",sc:["15.5"],nomSc:"15.5",corp:"CMMTQ"},
 chauffage:{l:"Chauffage",sc:["15.1","15.2","15.3","15.4"],nomSc:"15.1 à 15.4",corp:"CMMTQ"},
 electricite:{l:"Électricité",sc:[],nomSc:"licence de la CMEQ",corp:"CMEQ"},
 general:{l:"Rénovation générale (cuisine, salle de bain…)",sc:["1.2","1.3"],nomSc:"1.2 ou 1.3"}};
const GENERAL=["1.2","1.3"];
const chiffres=t=>String(t||"").replace(/\D/g,"");
const formatLicence=d=>d.length===10?d.replace(/(\d{4})(\d{4})(\d{2})/,"$1-$2-$3"):d;
const sansAccent=t=>String(t||"").normalize("NFD").replace(/[̀-ͯ]/g,"").toLowerCase()
 .replace(/\b(inc|ltee|ltd|enr|senc|la|le|les|de|du|des)\b\.?/g," ").replace(/[^a-z0-9]+/g," ").trim();
function memeNom(a,b){const x=sansAccent(a),y=sansAccent(b);return !!x&&!!y&&(x.includes(y)||y.includes(x))}
/* Délai de 10 jours (LPC art. 59) : le jour de départ ne compte pas ; une échéance un samedi, un dimanche,
   le 26 décembre ou le 2 janvier est reportée (LPC art. 269). Les autres jours fériés ne sont pas calculés. */
function dateLimite(iso){const d=new Date(iso+"T12:00:00");if(isNaN(d))return null;d.setDate(d.getDate()+10);
 const ferie=x=>x.getDay()===6||x.getDay()===0||(x.getMonth()===11&&x.getDate()===26)||(x.getMonth()===0&&x.getDate()===2);
 while(ferie(d))d.setDate(d.getDate()+1);return d}
const jourLong=d=>d.toLocaleDateString("fr-CA",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
const aujourdhui=()=>{const d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,10)};

/* R = fiche de la liste des licences actives de la RBQ ({numero,nom,autres_noms,sous_categories,mandataire})
   ou null si introuvable ; R === undefined quand la liste n'est pas disponible (démo, ou pas encore importée). */
function analyserReno(F,R){
 const it=[],T=TRAVAUX[F.travaux],lic=chiffres(F.licence);
 const L46="Loi sur le bâtiment, art. 46 · "+lien(LIENS.art46,"RBQ"),LSC="Liste des sous-catégories · "+lien(LIENS.souscat,"RBQ");
 if(!lic)it.push({c:"y",t:"<b>Aucun numéro de licence RBQ.</b> Demande-le : la loi exige une licence pour faire des travaux, et sans licence il n'y a pas de cautionnement pour t'indemniser.",law:L46});
 else if(R===undefined)it.push({c:"i",t:`<b>Licence ${esc(formatLicence(lic))} :</b> vérifie-la dans le registre officiel (bouton plus bas). Dans la version complète, l'app la compare seule à la liste des licences actives, mise à jour chaque jour.`,law:L46});
 else if(R===null)it.push({c:"r",t:`<b>Licence ${esc(formatLicence(lic))} introuvable</b> dans la liste des licences actives de la RBQ. Vérifie le numéro ; s'il est exact, l'entreprise n'a pas de licence en vigueur.`,law:L46});
 else{
  it.push({c:"g",t:`<b>Licence active</b> : ${esc(String(R.nom||formatLicence(lic)).replace(/\.$/,""))}.`,law:"Liste des licences actives, RBQ (données ouvertes)"});
  if(F.nom&&F.nom.trim()&&!memeNom(F.nom,R.nom)&&!memeNom(F.nom,R.autres_noms))
   it.push({c:"y",t:`<b>Le nom sur la soumission (« ${esc(F.nom)} ») ne correspond pas</b> au nom de la licence (« ${esc(R.nom)} »). Utiliser la licence d'une autre entreprise est interdit : demande une explication.`,law:L46});
  const sc=String(R.sous_categories||""),aSc=x=>new RegExp("(^|[^0-9.])"+x.replace(".","\\.")+"(?![0-9])").test(sc);
  if(T.corp&&!String(R.mandataire||"").toUpperCase().includes(T.corp)&&!T.sc.some(aSc)){
   if(GENERAL.some(aSc))it.push({c:"i",t:`Entrepreneur général : il peut confier ces travaux (${T.l.toLowerCase()}) à un sous-traitant, qui doit lui aussi avoir sa licence (${T.nomSc}).`,law:lien(LIENS.general,"RBQ, entrepreneur général")});
   else it.push({c:"y",t:`<b>Cette licence ne semble pas couvrir : ${T.l.toLowerCase()}.</b> Attendu : ${T.nomSc}.`,law:LSC});}
  else if(!T.corp&&!T.sc.some(aSc)){
   if(GENERAL.some(aSc))it.push({c:"i",t:`Entrepreneur général : il peut confier ces travaux à un sous-traitant, qui doit lui aussi avoir sa licence (sous-catégorie ${T.nomSc}).`,law:lien(LIENS.general,"RBQ, entrepreneur général")});
   else it.push({c:"y",t:`<b>Cette licence ne couvre pas : ${T.l.toLowerCase()}.</b> Sous-catégorie attendue : ${T.nomSc}.`,law:LSC});}
  else it.push({c:"g",t:`La licence couvre ce type de travaux (${T.nomSc}).`,law:LSC});}

 const LIT="Loi sur la protection du consommateur · "+lien(LIENS.itinerant,"OPC, commerce itinérant");
 F.limite=null;
 if(F.domicile==="oui"&&T.art7){
  const lim=dateLimite(F.recu||aujourdhui());F.limite=lim;
  it.push({c:"i",t:`<b>Contrat itinérant</b> : signé chez toi pour ce type de travaux, c'est un contrat itinérant même si tu as invité l'entrepreneur. Tu peux l'annuler sans frais ni raison jusqu'au <b>${lim?jourLong(lim):"10e jour"}</b>.`,law:"Règlement d'application de la LPC, art. 7 ; LPC, art. 59 · "+lien(LIENS.itinerant,"OPC")});
  if(F.acompte==="oui")it.push({c:"r",t:"<b>Paiement demandé pendant le délai d'annulation.</b> Un commerçant itinérant ne peut recevoir aucun paiement avant la fin des 10 jours.",law:"LPC, art. 60 · "+lien(LIENS.itinerant,"OPC")});
  it.push({c:"i",t:"Les travaux ne peuvent pas commencer avant la fin du délai, et l'entrepreneur doit détenir un permis de commerçant itinérant de l'OPC (bouton plus bas).",law:"LPC, art. 55 et 60.1 · "+lien(LIENS.lpc601,"OPC")});}
 else if(F.domicile==="oui"){
  it.push({c:"i",t:"<b>Signé chez toi :</b> si c'est l'entrepreneur qui t'a sollicité (porte-à-porte, appel), les règles du commerce itinérant s'appliquent : 10 jours pour annuler sans frais, aucun paiement ni début des travaux avant la fin de ce délai.",law:LIT});
  if(F.acompte==="oui")it.push({c:"y",t:"<b>Paiement demandé tout de suite.</b> Si l'entrepreneur t'a sollicité chez toi, il ne peut rien recevoir avant la fin des 10 jours.",law:"LPC, art. 60 · "+lien(LIENS.itinerant,"OPC")});}
 else if(F.acompte==="oui")
  it.push({c:"i",t:"<b>Acompte demandé.</b> Pas illégal ici, mais l'OPC recommande si possible aucun acompte à la signature, sinon une petite somme, puis des paiements selon l'avancement des travaux."});
 if(F.capture)it.push({c:"i",t:"Lecture automatique du numéro et du nom sur la photo : prochaine version."});
 const c=it.some(i=>i.c==="r")?"r":it.some(i=>i.c==="y")?"y":"g";
 const ord={r:0,y:1,i:2,g:3};it.sort((a,b)=>ord[a.c]-ord[b.c]);
 return {c,items:it};
}

/* Écrans communs du module. */
const vueReno=(F,retour)=>`${top(retour,"Rénovation")}
<h2>La soumission de l'entrepreneur</h2>
<form class="card" id="f-reno" novalidate>
<label class="drop">${F.captureUrl||(typeof F.capture==="string"&&F.capture)?`<img src="${F.captureUrl||F.capture}" alt="Photo de la soumission">Changer la photo`:"Photographier la soumission (facultatif)"}<input type="file" accept="image/*" capture="environment" data-side="capture"></label>
<div class="grid2"><label>Licence RBQ<input id="licence" inputmode="numeric" autocomplete="off" placeholder="0000-0000-00" value="${esc(F.licence||"")}"></label>
<label>Nom de l'entreprise<input id="nom" autocomplete="off" placeholder="Sur la soumission" value="${esc(F.nom||"")}"></label></div>
<div class="q">Type de travaux<div class="choix" role="group" aria-label="Type de travaux">${Object.entries(TRAVAUX).map(([k,t])=>`<button type="button" data-trav="${k}" aria-pressed="${F.travaux===k}">${t.l}</button>`).join("")}</div></div>
${yn("domicile","Le contrat est (ou sera) signé chez toi ?")}
<div id="q-recu" ${F.domicile!=="oui"?"hidden":""}><label>Date où tu as reçu ton exemplaire signé<input id="recu" type="date" value="${esc(F.recu||aujourdhui())}"></label></div>
${yn("acompte","On te demande un acompte ou un paiement maintenant ?")}
<p class="err" id="e" hidden></p>
<button class="btn" id="go">Vérifier</button></form>
<p class="hint">La photo reste sur ton téléphone. Seuls le numéro de licence, le type de travaux et le résultat sont gardés dans ton historique.</p>`;

const vueRenoResultat=(F,retour)=>{const R=F.res,T=TRAVAUX[F.travaux];return `${top(retour,"Résultat")}
<div class="verdict ${R.c}"><strong>${{r:"Ne signe pas, ne paie pas",y:"Prudence",g:"Aucun signal d'alarme"}[R.c]}</strong><span>${esc(T.l)}${F.licence?` · licence <span class="num">${esc(formatLicence(chiffres(F.licence)))}</span>`:""}</span></div>
${F.limite?`<div class="rule">Annulation possible sans frais jusqu'au <b>${jourLong(F.limite)}</b>.</div>`:""}
<div class="card"><h2>Ce que l'app a vérifié</h2><ul class="reasons">${R.items.map(i=>`<li><span class="dot ${i.c}"></span><div>${i.t}${i.law?`<div class="law">${i.law}</div>`:""}</div></li>`).join("")}</ul></div>
<p class="rule">Paie selon l'avancement des travaux, jamais tout d'avance.</p>
<a class="btn ghost" style="display:grid;place-items:center;text-decoration:none" href="${LIENS.opc}" target="_blank" rel="noopener" id="opc">Voir les plaintes à l'OPC</a>
<p class="hint">${F.nom?"En touchant le bouton, le nom de l'entreprise est copié : colle-le dans l'outil de l'OPC. ":""}Une plainte ne prouve pas une faute : regarde surtout leur nombre et leur sujet.</p>
<a class="btn ghost" style="display:grid;place-items:center;text-decoration:none" href="${LIENS.rbq}" target="_blank" rel="noopener">Ouvrir le registre des licences RBQ</a>
<button class="btn" id="nouv">Vérifier un autre entrepreneur</button>`};

/* Liaisons communes du formulaire. */
function lierReno(F){
 app.querySelectorAll("[data-trav]").forEach(b=>b.onclick=()=>{F.travaux=b.dataset.trav;app.querySelectorAll("[data-trav]").forEach(x=>x.setAttribute("aria-pressed",x===b))});
 app.querySelectorAll("[data-yn=domicile]").forEach(b=>b.addEventListener("click",()=>{$("#q-recu").hidden=F.domicile!=="oui"}));
}
function lireReno(F){["licence","nom","recu"].forEach(k=>{const el=$("#"+k);if(el)F[k]=el.value})}
function validerReno(F){const d=chiffres(F.licence);
 if(d&&(d.length<8||d.length>10))return "Ce numéro de licence semble incomplet. Recopie-le tel qu'il est sur la soumission, ou laisse le champ vide.";
 if(!F.travaux)return "Choisis le type de travaux.";
 if(!F.domicile||!F.acompte)return "Réponds aux deux questions.";
 if(F.domicile==="oui"&&F.recu&&isNaN(new Date(F.recu+"T12:00:00")))return "Entre une date valide.";
 return ""}
function lierResultatReno(F){const o=$("#opc");if(o&&F.nom)o.addEventListener("click",()=>{try{navigator.clipboard.writeText(F.nom)}catch(e){}})}

/* Lien reçu par « Partager » depuis une autre app (Android) ou par l'adresse ?url= */
try{const q=new URLSearchParams(location.search),tout=[q.get("title"),q.get("text"),q.get("url")].filter(Boolean).join("\n");
 if(tout){const l=normaliser(tout);if(l)F.lien=l;F.annonce=tout;F.partage=true;history.replaceState(null,"",location.pathname)}}catch(e){}
const $=s=>document.querySelector(s);
const app=$("#app");
const esc=t=>String(t??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const money=n=>Number(n).toLocaleString("fr-CA")+" $";
const top=(back,title)=>`<div class="top">${back?`<button class="back" data-go="${back}">‹ Retour</button>`:""}<b>${title||"Vérif-Logement"}</b><span class="sp"></span></div>`;
const STATUT={aucune:"Identité non confirmée",en_attente:"Identité en vérification",confirmee:"Identité confirmée",refusee:"Identité refusée : recommence"};

const V={
bienvenue:()=>`${top()}
<svg class="seal" role="img" aria-label="Bail avec sceau vérifié"><use href="#seal"/></svg>
<h1>Avant de payer, vérifie.</h1>
<p class="soft">Une annonce de logement ou la soumission d'un entrepreneur : l'app la vérifie en quelques secondes et te dit ce qui cloche, avec la loi qui s'applique. Sans inscription.</p>
<button class="btn" data-go="accueil" id="commencer">Commencer</button>
<button class="btn ghost" data-go="victime">J'ai été victime d'une arnaque</button>`,

inscription:()=>{const t=F.canal||"courriel";return `${top("accueil","Compte")}
<h2>${LS.get("vl_sig")?"Pour signaler, crée ton compte":"Garde ton historique"}</h2><p class="soft">Facultatif. Pas de mot de passe : tu reçois un code à 6 chiffres. Même chose pour te reconnecter sur un autre appareil.</p>
<form class="card" id="f-ins" novalidate>
<div class="seg" role="group" aria-label="Moyen de connexion">
<button type="button" data-canal="courriel" aria-pressed="${t==="courriel"}">Courriel</button>
<button type="button" data-canal="tel" aria-pressed="${t==="tel"}">Téléphone</button></div>
${t==="courriel"?`<label>Adresse courriel<input id="ident" type="email" inputmode="email" autocomplete="email" placeholder="nom@exemple.com" value="${esc(F.ident)}"></label>`
:`<label>Numéro de cellulaire<input id="ident" type="tel" inputmode="tel" autocomplete="tel" placeholder="514 555-0123" value="${esc(F.ident)}"></label>`}
<p class="err" id="e" hidden></p>
<button class="btn" id="go">Recevoir le code par ${t==="courriel"?"courriel":"SMS"}</button>
<p class="hint">Ton ${t==="courriel"?"courriel":"numéro"} sert seulement à te connecter.</p></form>`},

code:()=>`${top("inscription","Code")}
<h2>Entre le code reçu</h2><p class="soft">Envoyé à <b>${esc(F.affiche)}</b>. Vérifie aussi tes courriels indésirables.</p>
<form class="card" id="f-code" novalidate>
<div class="otp">${[0,1,2,3,4,5].map(i=>`<input inputmode="numeric" maxlength="1" aria-label="Chiffre ${i+1}" data-i="${i}" autocomplete="${i?"off":"one-time-code"}">`).join("")}</div>
<p class="err" id="e" hidden></p>
<button class="btn" id="go">Valider</button>
<button type="button" class="btn ghost" id="renvoi" disabled>Renvoyer le code (<span id="t">60</span> s)</button></form>`,

identite:()=>`${top("accueil","Identité")}
<h2>Confirme ton identité</h2><p class="soft">Une photo de ta pièce d'identité suffit. Pas de selfie.</p>
<form class="card" id="f-id" novalidate>
<label>Type de pièce<select id="doc">
<option value="permis">Permis de conduire</option><option value="passeport">Passeport</option><option value="rp">Carte de résident permanent</option></select></label>
<label class="drop">${F.rectoUrl?`<img src="${F.rectoUrl}" alt="Recto">Changer la photo`:"Prendre en photo le recto"}<input type="file" accept="image/*" capture="environment" data-side="recto"></label>
<label class="drop" ${F.doc==="passeport"?"hidden":""}>${F.versoUrl?`<img src="${F.versoUrl}" alt="Verso">Changer la photo`:"Prendre en photo le verso"}<input type="file" accept="image/*" capture="environment" data-side="verso"></label>
<label style="flex-direction:row;align-items:flex-start;gap:10px;font-weight:500"><input type="checkbox" id="ok" style="width:22px;min-height:22px;margin-top:2px">J'accepte que la photo serve uniquement à confirmer mon identité, puis soit supprimée.</label>
<p class="err" id="e" hidden></p>
<button class="btn" id="go">Envoyer pour vérification</button></form>
<p class="hint">Pourquoi ? Seuls les comptes à l'identité confirmée peuvent signaler une annonce : ça évite les fausses accusations. Vérifier une annonce ne la demande jamais.</p>
<p class="hint">Les photos sont envoyées dans un espace privé, au Canada. Seule l'équipe de vérification peut les voir ; elles sont supprimées après la vérification.</p>`,

analyse:()=>`${top(null,F.titre||"Vérification")}<div class="spin" role="status" aria-label="En cours"></div><p class="soft" style="text-align:center">${F.msg||"En cours…"}</p>`,

identiteOk:()=>`${top(null,"Identité")}
<svg class="seal" role="img" aria-label="Pièce reçue"><use href="#seal"/></svg>
<h1>Pièce reçue</h1><p class="soft">Ta pièce d'identité est en vérification. Tu pourras signaler des annonces dès qu'elle sera confirmée.</p>
<button class="btn" data-go="accueil">Continuer</button>`,

accueil:()=>`${top(null)}
${!ANONYME&&PROFIL?`<p class="badge" style="color:${PROFIL.identite_statut==="confirmee"?"var(--ok)":"var(--amber)"}">● ${STATUT[PROFIL.identite_statut]||"Connecté"} · ${esc(PROFIL.contact||"")}</p>`:""}
<h1>Que veux-tu vérifier ?</h1>
<button class="btn" data-go="verifier">Une annonce de logement</button>
<button class="btn" data-go="reno" id="nouvR">Un entrepreneur en rénovation</button>
${!ANONYME&&PROFIL&&["aucune","refusee"].includes(PROFIL.identite_statut)?`<button class="btn ghost" data-go="identite">Confirmer mon identité (pour signaler)</button>`:""}
<div class="card"><h2>Mes vérifications</h2>${ANONYME?`<p class="hint" style="margin:0">${SESSION?"Gardées sur ce téléphone. Crée un compte pour les retrouver ailleurs.":"Hors ligne : l'historique n'est pas gardé."}</p>`:""}${HIST.length?`<div class="hist">${HIST.map(x=>x.module==="reno"?`<div><span>Réno · ${esc((TRAVAUX[x.travaux]||{l:""}).l.split(/ \(|,/)[0])}${x.licence?` · <span class="num">${esc(formatLicence(x.licence))}</span>`:""}</span><span class="tag ${x.couleur}">${{r:"Ne pas signer",y:"Prudence",g:"Aucun signal"}[x.couleur]}</span></div>`:`<div><span>${esc(x.ville)} · ${x.chambres===3?"3+":x.chambres} ch. · <span class="num">${money(x.prix)}</span></span><span class="tag ${x.couleur}">${{r:"Arnaque probable",y:"Prudence",g:"Aucun signal"}[x.couleur]}</span></div>`).join("")}</div>`:`<p class="soft">Aucune vérification pour l'instant.</p>`}</div>
<button class="btn ghost" data-go="victime">J'ai été victime d'une arnaque</button>
${ANONYME?`<button class="btn ghost" data-go="inscription">Créer un compte (facultatif)</button>`:`<button class="btn ghost" id="deco">Se déconnecter</button>`}`,

verifier:()=>`${top("accueil","Vérifier")}
<h2>L'annonce</h2>
<form class="card" id="f-ver" novalidate>
<label>Texte de l'annonce<textarea id="annonce" placeholder="Colle ici le texte de l'annonce, ou partage-la vers l'app : elle lit le prix, la ville et le nombre de pièces">${esc(F.annonce||"")}</textarea></label>
<button type="button" class="btn ghost" id="lire">Lire l'annonce</button>
<label class="drop">${F.captureUrl?`<img src="${F.captureUrl}" alt="Capture de l'annonce">Changer la capture`:"Ou ajoute une capture d'écran de l'annonce"}<input type="file" accept="image/*" data-side="capture"></label>
${F.lu?`<p class="lu" role="status">${F.lu}</p>`:""}
<label>Lien de l'annonce (facultatif)<input id="lien" type="url" inputmode="url" autocomplete="off" placeholder="https://www.facebook.com/marketplace/item/…" value="${esc(F.lien)}"></label>
<label>Ville<select id="ville">${Object.keys(LOYERS).map(v=>`<option ${F.ville===v?"selected":""}>${esc(v)}</option>`).join("")}<option value="Autre" ${F.ville==="Autre"?"selected":""}>Autre ville</option></select></label>
<div class="grid2"><label>Chambres<select id="ch"><option value="1">1</option><option value="2">2</option><option value="3">3 et plus</option></select></label>
<label>Loyer demandé<input id="prix" inputmode="numeric" placeholder="1 300" value="${esc(F.prix)}"></label></div>
<label>Messages échangés (facultatif)<textarea id="txt" placeholder="Colle ici la conversation avec l'annonceur">${esc(F.txt)}</textarea></label>
${yn("argent","On te demande de l'argent avant la signature du bail ?")}
${yn("visite","As-tu pu visiter le logement en personne ?")}
${yn("cession","Est-ce une cession de bail ?")}
<div id="q-accord" ${F.cession!=="oui"?"hidden":""}>${yn("accord","Le propriétaire a-t-il accepté la cession par écrit ?")}</div>
<p class="err" id="e" hidden></p>
<button class="btn">Vérifier</button></form>
<p class="hint">Le texte de l'annonce et la conversation restent sur ton téléphone. Seuls la ville, le nombre de chambres, le prix, le lien et le résultat sont gardés. Si la recherche d'images est activée, la capture est envoyée à Google Vision pour cette recherche, puis n'est pas conservée.</p>`,

resultat:()=>{const R=F.res;return `${top("accueil","Résultat")}
<div class="verdict ${R.c}"><strong>${{r:"Arnaque probable",y:"Prudence",g:"Aucun signal d'alarme"}[R.c]}</strong><span>${esc(F.ville)} · ${F.ch==="3"?"3 ch. et plus":F.ch+" ch."} · <span class="num">${money(F.prixN)}</span></span></div>
<div class="card"><h2>Ce que l'app a vérifié</h2><ul class="reasons">${R.items.map(i=>`<li><span class="dot ${i.c}"></span><div>${i.t}${i.law?`<div class="law">${i.law}</div>`:""}</div></li>`).join("")}</ul></div>
<p class="rule">Ne paie rien avant d'avoir signé le bail et reçu les clés.</p>
<a class="btn ghost" style="display:grid;place-items:center;text-decoration:none" href="${ROLE[F.ville]||REGISTRE}" target="_blank" rel="noopener">Voir le propriétaire officiel</a>
<p class="hint">${ROLE[F.ville]?"Ouvre le rôle d'évaluation de la ville. Colle l'adresse et compare le nom avec celui de ton interlocuteur.":"Ouvre le Registre foncier du Québec (numéro de lot et frais de consultation requis)."}</p>
${boutonSignaler(F)}
${ANONYME?`<p class="hint">Crée un compte (facultatif) pour retrouver ton historique sur tous tes appareils.</p>`:""}
<button class="btn" id="nouv">Vérifier une autre annonce</button>`},
signaler:()=>vueSignaler(F,"accueil"),
signalOk:()=>vueSignalOk(),
attente:()=>`${top("accueil","Signaler")}<h2>Ta pièce est en vérification</h2><p class="soft">Tu pourras signaler des annonces dès que ton identité sera confirmée. En attendant, préviens Facebook Marketplace ou Kijiji directement.</p><button class="btn" data-go="accueil">Retour à l'accueil</button>`,

reno:()=>vueReno(F,"accueil"),
renoResultat:()=>vueRenoResultat(F,"accueil"),

victime:()=>`${top(LS.get("vl_vu")?"accueil":"bienvenue","Aide")}
<h2>Tu as été victime ?</h2>
<div class="card"><ul class="reasons">
<li><span class="dot i"></span><div><b>1. Appelle ta banque</b> tout de suite pour tenter de bloquer le virement.</div></li>
<li><span class="dot i"></span><div><b>2. Porte plainte à la police</b> de ta ville (poste de quartier, ou 911 en cas d'urgence).<div class="law">La fraude est un acte criminel : <a href="https://laws-lois.justice.gc.ca/fra/lois/c-46/section-380.html" target="_blank" rel="noopener">Code criminel, art. 380</a></div></div></li>
<li><span class="dot i"></span><div><b>3. Signale-le au Centre antifraude du Canada</b> : 1 888 495-8501.</div></li>
<li><span class="dot i"></span><div><b>4. Signale l'annonce</b> sur Facebook Marketplace ou Kijiji.</div></li></ul></div>
<p class="hint">Tes droits de locataire : <a href="https://www.tal.gouv.qc.ca" target="_blank" rel="noopener">Tribunal administratif du logement</a></p>
<p class="hint">Un problème avec un entrepreneur : <a href="https://www.opc.gouv.qc.ca" target="_blank" rel="noopener">Office de la protection du consommateur</a> et <a href="https://www.rbq.gouv.qc.ca/services-en-ligne/plainte-signalement-et-declaration/travail-sans-licence/" target="_blank" rel="noopener">RBQ, travail sans licence</a></p>`
};
function yn(k,q){return `<div class="q">${q}<div class="yn" role="group" aria-label="${esc(q)}"><button type="button" data-yn="${k}" data-v="oui" aria-pressed="${F[k]==="oui"}">Oui</button><button type="button" data-yn="${k}" data-v="non" aria-pressed="${F[k]==="non"}">Non</button></div></div>`}

function go(v){app.innerHTML=V[v]();window.scrollTo(0,0);bind(v)}
const err=m=>{const e=$("#e");if(e){e.textContent=m;e.hidden=!m}};
const busy=(on,label)=>{const b=$("#go");if(b){b.disabled=on;if(label)b.textContent=label}};
function appliquerLecture(r){["prix","ch","ville","cession"].forEach(k=>{if(r[k])F[k]=r[k]});if(r.lien&&!F.lien)F.lien=r.lien;
 const res=resumeLecture(r);F.lu=res?`<b>Lu :</b> ${esc(res)}. Vérifie et corrige si besoin.`:"Je n'ai pas trouvé le prix ni la ville : remplis-les ci-dessous."}
function keep(){["annonce","lien","ville","ch","prix","txt"].forEach(k=>{const el=$("#"+k);if(el)F[k]=el.value})}

/* Compte facultatif : chaque appareil reçoit une session anonyme ; créer un compte la relie à un courriel ou un cellulaire (même historique). */
async function ouvrirSession(){try{let {data}=await sb.auth.getSession();
 if(!data.session){const r=await sb.auth.signInAnonymously();if(r.error){SESSION=false;ANONYME=true;return}data={session:r.data.session}}
 SESSION=true;ANONYME=!!(data.session.user&&data.session.user.is_anonymous)}catch(e){SESSION=false;ANONYME=true}}
async function envoyerCode(){
 if(SESSION&&ANONYME){F.typeCode=F.cible.email?"email_change":"phone_change";const r=await sb.auth.updateUser(F.cible);
  const m=(r.error&&r.error.message||"").toLowerCase();if(!r.error||!(m.includes("already")||m.includes("registered")||m.includes("exists")))return r}
 F.typeCode=F.cible.email?"email":"sms";return sb.auth.signInWithOtp({...F.cible,options:{shouldCreateUser:true}})}
async function rechercheImages(f){try{const b64=await new Promise((ok,ko)=>{const r=new FileReader();r.onload=()=>ok(String(r.result).split(",")[1]);r.onerror=ko;r.readAsDataURL(f)});
 const appel=sb.functions.invoke("recherche-image",{body:{image:b64}});const {data,error}=await Promise.race([appel,new Promise(r=>setTimeout(()=>r({error:"delai"}),9000))]);
 /* La page de l'annonce elle-même n'est pas une copie : on retire les résultats du même site. */
 const hote=u=>{try{return new URL(u).hostname.replace(/^(www|m|web)\./,"")}catch(e){return ""}},site=F.lienN?hote(F.lienN):"";
 return error||!data?null:{ok:true,pages:(data.pages||[]).filter(u=>/^https?:\/\//.test(u)&&(!site||hote(u)!==site))}}catch(e){return null}}
async function chargerProfil(){
 if(!SESSION){PROFIL=null;HIST=[];return}
 const {data}=await sb.from("profiles").select("*").maybeSingle();PROFIL=data;
 const h=await sb.from("verifications").select("module,ville,chambres,prix,couleur,travaux,licence,created_at").order("created_at",{ascending:false}).limit(10);HIST=h.data||[];
}
async function chargerRegistre(){try{const {count,error}=await sb.from("licences_rbq").select("numero",{count:"exact",head:true});REGISTRE_PRET=!error&&count>0}catch(e){REGISTRE_PRET=false}}
async function chargerLoyers(){
 const {data}=await sb.from("loyers_reference").select("ville,chambres,loyer");
 LOYERS={};(data||[]).forEach(r=>{(LOYERS[r.ville]=LOYERS[r.ville]||[0,0,0])[r.chambres-1]=r.loyer});
 const ordre=Object.entries(LOYERS).sort((a,b)=>b[1][1]-a[1][1]);LOYERS=Object.fromEntries(ordre);
}
const msgAuth=e=>{const m=(e&&e.message||"").toLowerCase();
 if(m.includes("rate")||m.includes("seconds"))return "Trop de demandes. Attends une minute avant de redemander un code.";
 if(m.includes("phone")||m.includes("sms")||m.includes("provider"))return "L'envoi par SMS n'est pas encore activé. Utilise ton courriel.";
 if(m.includes("expired")||m.includes("invalid"))return "Code incorrect ou expiré.";
 return "Une erreur est survenue. Réessaie dans un instant.";};

function bind(v){
 app.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>{if(b.id==="nouvR")F={};go(b.dataset.go)});
 app.querySelectorAll("[data-canal]").forEach(b=>b.onclick=()=>{F.canal=b.dataset.canal;F.ident="";go("inscription")});
 app.querySelectorAll("[data-yn]").forEach(b=>b.onclick=()=>{F[b.dataset.yn]=b.dataset.v;b.parentNode.querySelectorAll("button").forEach(x=>x.setAttribute("aria-pressed",x===b));if(b.dataset.yn==="cession")$("#q-accord").hidden=b.dataset.v!=="oui"});
 app.querySelectorAll("input[type=file]").forEach(inp=>inp.onchange=()=>{const f=inp.files[0];if(!f)return;const s=inp.dataset.side;F[s]=f;F[s+"Url"]=URL.createObjectURL(f);keep();lireReno(F);if(v==="verifier"&&s==="capture")F.ocr=true;go(v)});

 if(v==="inscription")$("#f-ins").onsubmit=async e=>{e.preventDefault();err("");const val=$("#ident").value.trim();F.ident=val;
  if((F.canal||"courriel")==="courriel"){if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(val))return err("Entre une adresse courriel valide.");F.cible={email:val.toLowerCase()};F.affiche=val}
  else{const d=val.replace(/\D/g,"").replace(/^1(?=\d{10}$)/,"");if(d.length!==10)return err("Entre un numéro de 10 chiffres.");F.cible={phone:"+1"+d};F.affiche=d.replace(/(\d{3})(\d{3})(\d{4})/,"$1 $2-$3")}
  busy(true,"Envoi…");const {error}=await envoyerCode();
  if(error){busy(false,"Réessayer");return err(msgAuth(error))}go("code")};

 if(v==="code"){const ins=[...app.querySelectorAll(".otp input")];ins[0].focus();
  ins.forEach((x,i)=>{x.oninput=()=>{x.value=x.value.replace(/\D/g,"").slice(-1);if(x.value&&i<5)ins[i+1].focus()};
   x.onkeydown=e=>{if(e.key==="Backspace"&&!x.value&&i)ins[i-1].focus()};
   x.onpaste=e=>{const d=(e.clipboardData.getData("text")||"").replace(/\D/g,"").slice(0,6);if(d.length){e.preventDefault();d.split("").forEach((c,j)=>ins[j].value=c);ins[Math.min(d.length,5)].focus()}}});
  let t=60;const tick=setInterval(()=>{t--;const s=$("#t");if(!s){clearInterval(tick);return}s.textContent=t;if(t<=0){clearInterval(tick);$("#renvoi").disabled=false;$("#renvoi").textContent="Renvoyer le code"}},1000);
  $("#renvoi").onclick=async()=>{const {error}=await envoyerCode();if(error)return err(msgAuth(error));go("code")};
  $("#f-code").onsubmit=async e=>{e.preventDefault();err("");const token=ins.map(x=>x.value).join("");if(token.length<6)return err("Entre les 6 chiffres.");
   busy(true,"Vérification…");const {error}=await sb.auth.verifyOtp({...F.cible,token,type:F.typeCode});
   if(error){busy(false,"Valider");return err(msgAuth(error))}
   clearInterval(tick);F={};await chargerProfil();
   const sig=LS.get("vl_sig");if(sig){if(PROFIL&&PROFIL.identite_statut==="confirmee"){F=sig;return go("signaler")}return go(PROFIL&&PROFIL.identite_statut==="en_attente"?"attente":"identite")}
   go("accueil")}}

 if(v==="identite"){$("#doc").value=F.doc||"permis";$("#doc").onchange=e=>{F.doc=e.target.value;if(F.doc==="passeport"){F.verso=null;F.versoUrl=null}go("identite")};
  $("#f-id").onsubmit=async e=>{e.preventDefault();err("");const doc=F.doc||"permis";
   if(!F.recto)return err("Ajoute la photo du recto.");if(doc!=="passeport"&&!F.verso)return err("Ajoute la photo du verso.");if(!$("#ok").checked)return err("Coche la case pour continuer.");
   busy(true,"Envoi sécurisé…");const uid=(await sb.auth.getUser()).data.user.id,stamp=Date.now();
   for(const s of ["recto","verso"]){const f=F[s];if(!f)continue;const ext=(f.type.split("/")[1]||"jpg").replace("jpeg","jpg");
    const {error}=await sb.storage.from("pieces-identite").upload(`${uid}/${stamp}-${s}.${ext}`,f,{contentType:f.type,upsert:false});
    if(error){busy(false,"Réessayer");return err("L'envoi de la photo a échoué. Vérifie ta connexion (photo de 8 Mo maximum).")}}
   const {error}=await sb.rpc("soumettre_identite",{doc_type:doc});if(error){busy(false,"Réessayer");return err("Une erreur est survenue. Réessaie.")}
   F={};await chargerProfil();go("identiteOk")}}

 if(v==="accueil"&&$("#deco"))$("#deco").onclick=async()=>{await sb.auth.signOut();PROFIL=null;HIST=[];F={};await ouvrirSession();go("accueil")};
 if(v==="bienvenue")$("#commencer").addEventListener("click",()=>LS.set("vl_vu",true));
 if(v==="resultat"&&$("#signaler"))$("#signaler").onclick=()=>{const sig={lienN:F.lienN,ville:F.ville};LS.set("vl_sig",sig);
  if(ANONYME)return go("inscription");const st=PROFIL&&PROFIL.identite_statut;
  if(st==="confirmee"){F=sig;return go("signaler")}go(st==="en_attente"?"attente":"identite")};
 if(v==="signaler"){if(!F.lienN){const sig=LS.get("vl_sig");if(sig)F=sig}lierSignaler(F);$("#f-sig").onsubmit=async e=>{e.preventDefault();err("");const m=validerSignal(F);if(m)return err(m);
  busy(true,"Envoi…");const {error}=await sb.from("signalements").insert({lien:F.lienN,motif:F.motif});
  if(error&&!String(error.code).includes("23505")){busy(false,"Réessayer");return err("Le signalement n'a pas pu être envoyé. Réessaie.")}
  LS.set("vl_sig",null);F={};go("signalOk")}}
 if(v==="verifier"){$("#lire").onclick=()=>{keep();appliquerLecture(extraireAnnonce(F.annonce,Object.keys(LOYERS)));go("verifier")};
  if(F.partage){F.partage=false;appliquerLecture(extraireAnnonce(F.annonce,Object.keys(LOYERS)));return go("verifier")}
  if(F.ocr){F.ocr=false;F.lu=null;$("#f-ver").insertAdjacentHTML("afterbegin",`<p class="lu" role="status">Lecture de la capture…</p>`);
   lireCapture(F.capture).then(txt=>{const ici=$("#f-ver");if(ici)keep();F.annonce=((F.annonce||"")+"\n"+txt).trim();appliquerLecture(extraireAnnonce(txt,Object.keys(LOYERS)));if(ici)go("verifier")})
   .catch(()=>{F.lu="La lecture de la capture n'a pas fonctionné. Colle plutôt le texte de l'annonce.";if($("#f-ver"))go("verifier")})}}

 if(v==="verifier"){$("#ch").value=F.ch||"2";$("#f-ver").onsubmit=async e=>{e.preventDefault();keep();err("");
  F.prixN=parseInt(String(F.prix).replace(/\D/g,""),10);if(!F.prixN||F.prixN<100)return err("Entre le loyer demandé.");
  if(!F.argent||!F.visite||!F.cession)return err("Réponds aux trois questions.");if(F.cession==="oui"&&!F.accord)return err("Dis-nous si le propriétaire a accepté par écrit.");
  F.lienN=normaliser(F.lien);if(F.lien&&F.lien.trim()&&!F.lienN)return err("Ce lien n'est pas valide. Colle l'adresse complète de l'annonce, ou laisse le champ vide.");
  F.titre="Vérification";F.msg="Analyse de l'annonce…";go("analyse");
  F.stats=null;F.nbSig=0;F.images=null;
  if(F.lienN&&SESSION){const [a,b]=await Promise.all([sb.rpc("stats_lien",{p_lien:F.lienN}),sb.rpc("nb_signalements",{p_lien:F.lienN})]);F.stats=a.data&&a.data[0];F.nbSig=+b.data||0}
  if(F.capture)F.images=await rechercheImages(F.capture);
  F.res=analyser();
  const brut=F.res.items.map(i=>({c:i.c,t:i.t.replace(/<[^>]+>/g,"")}));
  const ins=SESSION?sb.from("verifications").insert({ville:F.ville,chambres:+F.ch,prix:F.prixN,couleur:F.res.c,raisons:brut,lien:F.lienN}):Promise.resolve();
  await Promise.all([ins,new Promise(r=>setTimeout(r,900))]);await chargerProfil();go("resultat")}}
 if(v==="resultat")$("#nouv").onclick=()=>{F={};go("verifier")};

 if(v==="reno"){lierReno(F);$("#f-reno").onsubmit=async e=>{e.preventDefault();lireReno(F);err("");const m=validerReno(F);if(m)return err(m);
  const lic=chiffres(F.licence);F.titre="Vérification";F.msg="Analyse de la soumission…";go("analyse");
  let R;/* undefined = registre pas encore importé : l'app renvoie au registre officiel */
  if(lic&&REGISTRE_PRET){const {data,error}=await sb.from("licences_rbq").select("numero,nom,autres_noms,sous_categories,mandataire").eq("numero",lic).maybeSingle();if(!error)R=data||null}
  F.res=analyserReno(F,R);
  const brut=F.res.items.map(i=>({c:i.c,t:i.t.replace(/<[^>]+>/g,"")}));
  const ins=!SESSION?Promise.resolve():sb.from("verifications").insert({module:"reno",travaux:F.travaux,licence:lic||null,couleur:F.res.c,raisons:brut});
  await Promise.all([ins,new Promise(r=>setTimeout(r,700))]);await chargerProfil();go("renoResultat")}}
 if(v==="renoResultat"){lierResultatReno(F);$("#nouv").onclick=()=>{F={};go("reno")}}
}

function analyser(){
 const it=[],txt=((F.txt||"")+" "+(F.annonce||"")).toLowerCase(),L1904='Code civil du Québec, art. 1904 · <a href="https://www.quebec.ca/nouvelles/actualites/details/exiger-un-depot-de-garantie-est-illegal" target="_blank" rel="noopener">Québec.ca</a>';
 const motA=MOTS_ARGENT.find(m=>txt.includes(m)),motS=MOTS_SCENARIO.find(m=>txt.includes(m));
 if(F.argent==="oui")it.push({c:"r",t:"<b>On te demande de l'argent avant le bail.</b> Au Québec, le propriétaire peut seulement exiger le premier mois de loyer, et aucun dépôt.",law:L1904});
 if(motA)it.push({c:"r",t:`<b>La conversation parle de « ${esc(motA)} ».</b> Tout dépôt ou frais de réservation est illégal.`,law:L1904});
 if(motS)it.push({c:"y",t:`<b>Scénario d'arnaque courant</b> repéré dans la conversation : « ${esc(motS)} ».`});
 if(F.visite==="non")it.push({c:"y",t:"<b>Tu n'as pas visité.</b> Ne paie rien sans avoir vu le logement en personne."});
 else it.push({c:"g",t:"Tu as visité le logement. Attention : un fraudeur peut louer un logement quelques jours pour le faire visiter."});
 if(F.cession==="oui")it.push(F.accord==="oui"?{c:"g",t:"Accord écrit du propriétaire pour la cession : bon signe."}:{c:"y",t:"<b>Cession sans accord écrit du propriétaire.</b> Il peut refuser ; ne paie rien avant sa réponse écrite.",law:'Code civil du Québec, art. 1870 et 1871 · <a href="https://www.tal.gouv.qc.ca/sites/default/files/notices/TAL_828_E.pdf" target="_blank" rel="noopener">TAL</a>'});
 if(F.lienN){const h=new URL(F.lienN).hostname,site=SITES.find(s=>h===s.d||h.endsWith("."+s.d));
  if(!site)it.push({c:"y",t:`<b>Site inconnu : ${esc(h)}.</b> Les fraudeurs copient parfois de vrais sites d'annonces. Vérifie l'adresse lettre par lettre.`});
  const st=F.stats;if(st&&+st.rouges>0)it.push({c:"r",t:`<b>${st.rouges} vérification${st.rouges>1?"s":""} précédente${st.rouges>1?"s":""} de cette annonce ${st.rouges>1?"ont":"a"} donné « Arnaque probable ».</b>`});
  else if(st&&+st.total>0)it.push({c:"i",t:`Cette annonce a déjà été vérifiée ${st.total} fois, sans arnaque probable.`});
  const sg=itemSignalements(F.nbSig);if(sg)it.push(sg);}
 if(F.images&&F.images.pages&&F.images.pages.length)it.push({c:"y",t:`<b>Ces images apparaissent sur ${F.images.pages.length} autre${F.images.pages.length>1?"s":""} page${F.images.pages.length>1?"s":""} du web.</b> Les fraudeurs copient souvent les photos d'une vraie annonce. ${F.images.pages.slice(0,3).map(u=>`<a href="${esc(u)}" target="_blank" rel="noopener">${esc(new URL(u).hostname)}</a>`).join(", ")}`,law:"Recherche d'image inversée (Google Vision)"});
 else if(F.images&&F.images.ok)it.push({c:"g",t:"Les images de la capture n'ont pas été trouvées ailleurs sur le web."});
 if(F.capture&&!F.images)it.push({c:"i",t:"Recherche des photos ailleurs sur le web : pas encore activée."});
 const loy=LOYERS[F.ville],moy=loy&&loy[Math.min(+F.ch,3)-1],LSCHL="SCHL, loyers moyens octobre 2025";
 /* Prix bas : jamais un signal à lui seul (vieil immeuble, quartier moins cher, propriétaire de longue date).
    Il ne devient jaune que s'il s'ajoute à un autre signal d'alarme. */
 const autreSignal=it.some(i=>i.c==="r"||i.c==="y");
 if(moy){const r=F.prixN/moy;
  if(r<BAS&&F.cession==="oui")it.push({c:"i",t:`<b>Prix sous la moyenne</b> (${money(moy)} à ${esc(F.ville)}) : normal pour une cession, car le nouveau locataire reprend le bail existant et son loyer.`,law:'Code civil du Québec, art. 1870 à 1873 · <a href="https://www.tal.gouv.qc.ca/sites/default/files/notices/TAL_817_E.pdf" target="_blank" rel="noopener">TAL</a>'});
  else if(r<BAS&&autreSignal)it.push({c:"y",t:`<b>Prix nettement sous la moyenne, en plus d'un autre signal.</b> ${money(F.prixN)} contre ${money(moy)} en moyenne à ${esc(F.ville)}. Un prix trop beau combiné à ces signaux est l'appât classique des fausses annonces.`,law:LSCHL});
  else if(r<BAS)it.push({c:"i",t:`<b>Prix sous la moyenne</b> (${money(moy)} à ${esc(F.ville)}). Ça arrive souvent : vieil immeuble, quartier moins cher, propriétaire de longue date. Pas un signe d'arnaque à lui seul.`,law:LSCHL});
  else if(r>HAUT)it.push({c:"i",t:`<b>Prix élevé</b> (${money(moy)} en moyenne). Pas une arnaque en soi : vérifie la section G du bail. Tu peux demander au Tribunal de fixer le loyer dans les 10 jours suivant la signature.`,law:'Code civil du Québec, art. 1896 · <a href="https://www.tal.gouv.qc.ca/sites/default/files/Ajustement-bail-logement.pdf" target="_blank" rel="noopener">TAL, formulaire de bail</a>'});
  else it.push({c:"g",t:`<b>Prix dans la normale</b> pour ${esc(F.ville)} (${money(moy)} en moyenne).`,law:LSCHL})}
 else it.push({c:"i",t:"Pas encore de loyer de référence pour cette ville."});
 const c=it.some(i=>i.c==="r")?"r":it.some(i=>i.c==="y")?"y":"g";
 const ord={r:0,y:1,i:2,g:3};it.sort((a,b)=>ord[a.c]-ord[b.c]);
 return {c,items:it};
}

/* Partage reçu dans l'app native (iPhone/Android), voir app-native/partage-natif.js. */
window.recevoirPartage=t=>{if(!t)return;F={annonce:String(t).slice(0,5000),partage:true};const l=normaliser(t);if(l)F.lien=l;go("verifier")};
(async()=>{
 try{if("serviceWorker" in navigator)navigator.serviceWorker.register("sw.js").catch(()=>{})}catch(e){}
 go("analyse");
 try{await Promise.all([chargerLoyers(),chargerRegistre()]);
  await ouvrirSession();await chargerProfil();go(F.partage?"verifier":LS.get("vl_vu")?"accueil":"bienvenue")}
 catch(e){app.innerHTML=`${top()}<p class="err">Impossible de joindre le serveur. Vérifie ta connexion et recharge la page.</p>`}
})();
}
