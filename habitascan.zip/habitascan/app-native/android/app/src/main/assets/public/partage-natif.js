/* Reçoit une annonce partagée depuis Facebook, Kijiji, etc. (bouton Partager du téléphone)
   et l'envoie à l'écran de vérification. Plugin : @capgo/capacitor-share-target. */
(function () {
  const C = window.Capacitor;
  const plugin = C && C.Plugins && C.Plugins.CapacitorShareTarget;
  if (!plugin) return;
  plugin.addListener("shareReceived", (e) => {
    const morceaux = [e.title, ...(e.texts || [])].filter(Boolean);
    if (morceaux.length && window.recevoirPartage) window.recevoirPartage(morceaux.join("\n"));
  });
})();
