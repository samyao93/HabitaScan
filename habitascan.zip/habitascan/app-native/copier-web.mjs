// Copie la version web dans www/ et ajoute la réception des partages natifs.
import fs from "node:fs";
import path from "node:path";

const src = path.resolve("..");
const dest = path.resolve("www");
fs.rmSync(dest, { recursive: true, force: true });
fs.mkdirSync(dest);
for (const f of ["index.html", "app.js", "icon.svg", "manifest.webmanifest"]) {
  fs.copyFileSync(path.join(src, f), path.join(dest, f));
}
fs.copyFileSync("partage-natif.js", path.join(dest, "partage-natif.js"));
// Dans l'app native, pas de service worker ; on ajoute le script de partage après app.js.
const html = fs.readFileSync(path.join(dest, "index.html"), "utf8")
  .replace('<script src="app.js"></script>', '<script src="app.js"></script>\n<script src="partage-natif.js"></script>');
fs.writeFileSync(path.join(dest, "index.html"), html);
console.log("www/ prêt");
